﻿
using UnityEngine;
using System.Collections;

public enum GameState{
	menu,
	inGame,
	gameOver
}

public class GameManager : MonoBehaviour {
	public static GameManager instance;

	public GameState currentGameState = GameState.menu;
	void Awake(){
		instance = this;
	}

	void Start(){
		currentGameState = GameState.menu;
	}

	void Update(){
		if (Input.GetButtonDown ("s"))
		//if(currentGameState == GameState.inGame)
			StartGame ();

			/*
			 * if(Input.GetKey (KeyCode.S))
				StartGame();
			else 
				if(Input.GetKey(KeyCode.Q))
					GameOver ();
				else 
					if(Input.GetKey(KeyCode.M))
						BackToMenu ();
					else
						if(currentGameState == GameState.menu)
							Debug.Log("tasti comando: s start q quit m menu");
			*/
                             	}

	// chiamata per iniziare il gioco
	public void StartGame () {
		PlayerController.instance.StartGame ();
		SetGameState (GameState.inGame);
		Debug.Log("stato inGame");

	}
	
	// chiamata quando il giocatore muore
	public void GameOver () {
		SetGameState (GameState.gameOver);
		Debug.Log("stato gameOver");
	}

	// chiamata quando il giocatore decide di tornare al menu
	public void BackToMenu () {
		SetGameState (GameState.menu);
		Debug.Log("stato menu: premi s per iniziare");
	}

	void SetGameState(GameState newGameState){
		if (newGameState == GameState.menu) {
		} else if (newGameState == GameState.inGame) {
		} else if (newGameState == GameState.gameOver) {
		}

		/*!!!!!! senza GameManager.instance lo stato 
		non risulta aggiornato nello script PlayerController
		nel coso in cui GameManager.StartGame 
		è lanciato dal bottone e non da tasto "s"
		*/
		GameManager.instance.currentGameState = newGameState;
	}
}
